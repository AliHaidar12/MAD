package com.example.sqltask

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val context = this
        add.setOnClickListener({
            if ( tex1.text.toString().length >0 &&
                    tex2.text.toString().length >0 &&
                    tex3.text.toString().length >0 ){
                var users = user(tex1.text.toString(),tex2.text.toString(),tex3.text.toString())
                var db = DataBaseHandler(context)
                db.insertData(users)

            }
            else
                Toast.makeText(context,"Please fill the fields",Toast.LENGTH_LONG).show()


        })



    }
}