package com.example.sqltask

class user {
    var id: Int =0
    var name:String = ""
    var sessi:String = ""
    var reg:String = ""

    constructor(name: String,sessi:String,reg:String){
        this.name=name
        this.sessi=sessi
        this.reg=reg
    }

}