import pygame , sys
from pygame.locals import *
import random

# Initialize program
pygame.init()


pygame.font.init()
headingfont = pygame.font.SysFont('sans sarif', 30)
elfont = pygame.font.SysFont('sans sarif', 25)

# Assign FPS a value
FPS = 30
FramePerSec = pygame.time.Clock()


gamestart = True
# Setting up color objects
BLUE = (0, 0, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
GREY = (144,144,144)
WHITE = (255, 255, 255)

WIDTH = 500
HEIGHT = 500
DISPLAYSURF = pygame.display.set_mode((WIDTH, HEIGHT))
DISPLAYSURF.fill(BLUE)
pygame.display.set_caption("Find The Shark")

opened = [False , False , False]
tries = 2
list = ['shark' , 'Beach ball' , 'palm tree']
correct = 0
def reset():
    global opened, tries , list , correct , gamestart
    opened = [False, False, False]
    tries = 2
    random.shuffle(list)
    correct = list.index('shark')
    print(list)
    gamestart = True
# Creating Lines and Shapes
def draw_rect(start ,color , text):
    b = pygame.draw.rect(DISPLAYSURF, color, (start, 150, 100, 100), 0)
    DISPLAYSURF.blit(elfont.render(text, False, WHITE), (start+10, 190))
    return b
def inialize():
    textsurface = headingfont.render('Find The Shark', False, WHITE)
    DISPLAYSURF.blit(textsurface, (WIDTH / 2 - (textsurface.get_width() / 2), 50))
    if opened[0]:
        b1 = draw_rect((1 * (WIDTH / 5) - 50 ), GREEN if correct==0 else RED, list[0])
    else:
       b1 =  draw_rect((1 * (WIDTH / 5) - 50), GREY, '        ?')
    if opened[1]:
        b2 = draw_rect((3 * (WIDTH / 5) - 100), GREEN if correct==1 else RED, list[1])
    else:
        b2 = draw_rect((3 * (WIDTH / 5) - 100), GREY, '       ?')
    if opened[2]:
        b3 = draw_rect((5 * (WIDTH / 5) - 150), GREEN if correct==2 else RED, list[2])
    else:
        b3 = draw_rect((5 * (WIDTH / 5) - 150), GREY, '       ?')

    r = pygame.draw.rect(DISPLAYSURF, GREY, (50, 450, 70,20), 0)
    DISPLAYSURF.blit(elfont.render("Reset", False, WHITE), (60 , 450))

    return [b1,b2,b3 , r]

def win():
    textsurface = headingfont.render('You won', False, WHITE)
    DISPLAYSURF.blit(textsurface, (WIDTH / 2 - (textsurface.get_width() / 2), 300))

def gameover():
    textsurface = headingfont.render('You lost', False, WHITE)
    DISPLAYSURF.blit(textsurface, (WIDTH / 2 - (textsurface.get_width() / 2), 300))

# Beginning Game Loop
while True:
    pygame.display.update()
    if gamestart:
        DISPLAYSURF.fill(BLUE)
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONUP:
            pos = pygame.mouse.get_pos()
            if gamestart:
                for i in range(len(boxes)-1):
                    if boxes[i].collidepoint(pos):
                        opened[i] = True
                        if i == correct:
                            gamestart = False
                            win()
                        else:
                            tries -= 1
                        if tries <= 0:
                            gamestart = False
                            gameover()
            if boxes[3].collidepoint(pos):
                reset()

    boxes = inialize()
    FramePerSec.tick(FPS)
