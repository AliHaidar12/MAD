from django.urls import path

from . import views

urlpatterns = [

    path('', views.index, name='index'),
    path('<int:pk>/', views.detail, name='detail'),
    path('api/', views.index_api, name='api_index'),
    path('api/<int:pk>/', views.detail_api, name='api_detail'),
]