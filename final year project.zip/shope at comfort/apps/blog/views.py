from django.shortcuts import render

from . models import Post
from . serializer import PostSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response


def index(request):
    posts = Post.objects.all()

    return render(request, 'blog/index.html', {'posts': posts , 'latest_posts':posts[:10]})


def detail(request, pk):
     post = Post.objects.get(pk=pk) 

     return render(request, 'blog/detail.html', {'post': post})


@api_view()
def index_api(request):
    posts = Post.objects.all()
    serializer = PostSerializer(posts, many=True)
    return Response(serializer.data, status=401)

@api_view()
def detail_api(request, pk):
     post = Post.objects.get(pk=pk)
     serializer = PostSerializer(post, many=False)
     return Response(serializer.data , status = 401)