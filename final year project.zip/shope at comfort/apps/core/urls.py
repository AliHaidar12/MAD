#
#

from django.urls import path

#
#

from . import views

#
#

urlpatterns = [
    path('api', views.frontpage_api, name='frontpage_api'),
    path('', views.frontpage, name='frontpage'),
    path('contact/', views.contact, name='contact'),
    path('about/', views.about, name='about'),
    path('pricing/', views.pricing, name='pricing'),
    path('frequently_asked_questions/', views.frequently_asked_questions,
         name='frequently_asked_questions'),
    path('termsandconditions/', views.termsandconditions,
         name='termsandconditions'),

]
