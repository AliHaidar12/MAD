from django.shortcuts import render

from apps.product.models import Product, Category, SubCategory, SubSubCategory,Product_Review
from apps.blog.models import Post
from apps.product.serializer import CategorySerializer, SubCategorySerializer , ProductSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.template.defaulttags import register
from django.core.mail import mail_managers

from django.conf import settings


@register.filter
def get_range(value):
    return range(value)


def frontpage(request):
    newest_products = Product.objects.filter(parent=None, visible=True, vendor__enabled=True)
    featured_products = Product.objects.filter(is_featured=True, visible=True, vendor__enabled=True)
    all_products = Product.objects.filter(visible=True, vendor__enabled=True)
    featured_categories = Category.objects.filter(is_featured=True)
    featured_categories_products = []
    for category in featured_categories:
        for sub_category in SubCategory.objects.filter(category=category):
            for subsubcategory in SubSubCategory.objects.filter(sub_category=sub_category):
                for product in Product.objects.filter(category=subsubcategory):
                    if product.vendor.enabled and product.visible:
                        featured_categories_products.append(product)

    popular_products = Product.objects.filter(parent=None, visible=True, vendor__enabled=True).order_by('-num_visits')
    recently_viewed_products = Product.objects.filter(parent=None, visible=True, vendor__enabled=True).order_by('-last_visit')
    posts = Post.objects.all()[:4]
    return render(request, 'core/frontpage.html', {'newest_products': newest_products, 'all_products': all_products, 'featured_products': featured_products, 'featured_categories': featured_categories, 'popular_products': popular_products, 'recently_viewed_products': recently_viewed_products, 'featured_categories_products': featured_categories_products , 'posts':posts})

@api_view()
def frontpage_api(request):
    newest_products = Product.objects.filter(
        parent=None)
    featured_products = Product.objects.filter(is_featured=True)
    featured_categories = Category.objects.filter(is_featured=True)
    featured_categories_products = []
    for category in featured_categories:
        for sub_category in SubCategory.objects.filter(category=category):
            for subsubcategory in SubSubCategory.objects.filter(sub_category=sub_category):
                for product in Product.objects.filter(category=subsubcategory):
                    if product.vendor.enabled and product.visible:
                        featured_categories_products.append(product)

    popular_products = Product.objects.all().order_by('-num_visits')
    recently_viewed_products = Product.objects.all().order_by(
        '-last_visit')

    newest_products = ProductSerializer(newest_products , many=True)
    featured_products = ProductSerializer(featured_products , many=True)
    featured_categories = CategorySerializer(featured_categories , many=True)
    popular_products = ProductSerializer(popular_products , many=True)
    recently_viewed_products = ProductSerializer(recently_viewed_products , many=True)
    featured_categories_products = ProductSerializer(featured_categories_products , many=True)
    return Response({'newest_products':newest_products.data,
                     'featured_products':featured_products.data,
                     'featured_categories':featured_categories.data,
                     'popular_products':popular_products.data,
                     'recently_viewed_products':recently_viewed_products.data,
                     'featured_categories_products':featured_categories_products.data,
                     })


def contact(request):
    if request.method=='POST':
        to=request.POST.get('tomail')
        name=request.POST.get('form-name')
        message = request.POST.get('contect')
        subject = request.POST.get('subject')
        message = f'''
        Request from : {to}
        Sender Name : {name}
        Subject : {subject}
        Mssage :
        {message}
        '''
        mail_managers(subject,message)
        return render(request, 'core/contact.html')
    else:
        print("not send")
        return render(request, 'core/contact.html')

def about(request):
    return render(request, 'core/about.html')


def pricing(request):
    return render(request, 'core/pricing.html')


def frequently_asked_questions(request):
    return render(request, 'core/frequently_asked_questions.html')


def termsandconditions(request):
    return render(request, 'core/termsandconditions.html')
