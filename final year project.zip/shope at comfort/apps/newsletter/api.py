import json

from django.http import JsonResponse

from .models import Subscriber


def api_add_subscriber(request):
    data = json.loads(request.body)
    email = data['email']
    print("added")
    s = Subscriber.objects.create(email=email)
    print("added")
    return JsonResponse({'success': True})
