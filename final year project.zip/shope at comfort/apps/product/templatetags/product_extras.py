import markdown

from django import template
from django.template.defaultfilters import stringfilter

register = template.Library()


@register.filter
def convert_markdown(value):
    return markdown.markdown(value, extensions=['markdown.extensions.fenced_code'])

@register.filter
def rang( paras):
    return range(0 , len(paras) , 20)

@register.filter
def sli(data, f ):
    to = f+20
    return data[f: to if to<=len(data) else len(data)]

@register.filter
def slugify(name):
    return name.replace(" " , "_")
