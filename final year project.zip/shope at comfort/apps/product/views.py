import random

from datetime import datetime

from django.contrib import messages
from django.db.models import Q
from django.shortcuts import render, get_object_or_404, redirect

from .forms import AddToCartForm, AddToCartInListForm, ReviewForm
from .models import Category, ProductImage, SubCategory, SubSubCategory, Product, Product_Review
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializer import ProductSerializer , CategorySerializer , SubCategorySerializer , SubSubCategorySerializer
from apps.cart.cart import Cart


def quickview(request):
    cart = Cart(request)
    idx = request.GET['idx']
    product = Product.objects.get(id=idx)
    print(product.title)
    if cart.has_product(product.id):
        product.in_cart = True
    else:
        product.in_cart = False
    product_imgs = ProductImage.objects.filter(product=product)
    return render(request, 'product/parts/quickview.html', {'product':product , 'imgs':product_imgs})

def search(request):
    query = request.GET.get('query', '')
    instock = request.GET.get('instock')
    price = request.GET.get('price')
    price_from = request.GET.get('price_from', 0)
    price_to = request.GET.get('price_to', 5000000)
    print(price_to)
    sorting = request.GET.get('sorting', '-date_added')
    products = Product.objects.filter(Q(title__icontains=query) | Q(
        description__icontains=query))
        # .filter(price__gte=price_from).filter(price__lte=price_to)

    if instock:
        products = products.filter(num_available__gte=1, visible=True, vendor__enabled=True)
    products_id = []
    for product in products:
        if product.get_discounted_price() >= float(price_from) and product.get_discounted_price() <= float(price_to):
            products_id.append(product.id)
    products = Product.objects.filter(Q(id__in=products_id)) 

    return render(request, 'product/search.html', {'products': products.order_by(sorting), 'query': query, 'instock': instock, 'price_from': price_from, 'price_to': price_to, 'sorting': sorting})

@api_view()
def search_api(request):
    query = request.GET.get('query', '')
    instock = request.GET.get('instock')
    price_from = request.GET.get('price_from', 0)
    price_to = request.GET.get('price_to', 5000000)
    sorting = request.GET.get('sorting', '-date_added')
    products = Product.objects.filter(Q(title__icontains=query) | Q(
        description__icontains=query))
    if instock:
        products = products.filter(num_available__gte=1)
    products_id = []
    for product in products:
        if product.get_discounted_price() >= float(price_from) and product.get_discounted_price() <= float(price_to):
            products_id.append(product.id)
    products = Product.objects.filter(Q(id__in=products_id))
    products = ProductSerializer(products,many=True)
    return Response({'products': products.order_by(sorting), 'query': query, 'instock': instock, 'price_from': price_from, 'price_to': price_to, 'sorting': sorting})


def product(request, vendorslug, category_slug, subcategory_slug, subsubcategory_slug, product_slug):
    cart = Cart(request)

    product = get_object_or_404(
        Product, category__slug=subsubcategory_slug, slug=product_slug, visible=True, vendor__enabled=True)
    product.num_visits = product.num_visits + 1
    product.last_visit = datetime.now()
    product.save()

    if request.method == 'POST' and (not request.POST.get('add_cart')):
        review = ReviewForm(request.POST)
        if review.is_valid():
            r = review.save(commit=False)
            r.customer_id = request.user.customer
            r.product_id = product
            r.save()
            print('asdfghd')


    if request.method == 'POST':
        form = AddToCartForm(request.POST)
        # review = ReviewForm(request.POST)
        if form.is_valid() :
            quantity = form.cleaned_data['quantity']

            cart.add(product_id=product.id,
                     quantity=quantity, update_quantity=False)

            messages.info(request, product.title+' was added to the cart')

            return redirect('product',vendorslug= vendorslug, category_slug=category_slug, subcategory_slug=subcategory_slug, subsubcategory_slug=subsubcategory_slug, product_slug=product_slug)
    else:
        form = AddToCartForm()

    similar_products = list(product.category.products.exclude(id=product.id).filter(visible=True))

    if len(similar_products) >= 4:
        similar_products = random.sample(similar_products, 4)

    cart = Cart(request)

    if cart.has_product(product.id):
        product.in_cart = True
    else:
        product.in_cart = False
    product_imgs = ProductImage.objects.filter(product=product)
    review = ReviewForm()
    return render(request, 'product/product.html', {'review':review,'form': form, 'product': product, 'imgs': product_imgs, 'similar_products': similar_products})
@api_view()
def product_api(request, vendorslug, category_slug, subcategory_slug, subsubcategory_slug, product_slug):
    cart = Cart(request)

    product = get_object_or_404(
        Product, category__slug=subsubcategory_slug, slug=product_slug, visible=True, vendor__enabled=True)
    product.num_visits = product.num_visits + 1
    product.last_visit = datetime.now()
    product.save()

    if request.method == 'POST':
        form = AddToCartForm(request.POST)

        if form.is_valid():
            quantity = form.cleaned_data['quantity']

            cart.add(product_id=product.id,
                     quantity=quantity, update_quantity=False)

            messages.success(request, 'The product was added to the cart')

            return redirect('product',vendorslug= vendorslug, category_slug=category_slug, subcategory_slug=subcategory_slug, subsubcategory_slug=subsubcategory_slug, product_slug=product_slug)
    else:
        form = AddToCartForm()

    similar_products = list(product.category.products.exclude(id=product.id))

    if len(similar_products) >= 4:
        similar_products = random.sample(similar_products, 4)

    cart = Cart(request)

    if cart.has_product(product.id):
        product.in_cart = True
    else:
        product.in_cart = False
    product_imgs = ProductImage.objects.filter(product=product)
    product = ProductSerializer(product,many=False)
    similar_products = ProductSerializer(similar_products , many=True)
    return Response({'product': product.data,'similar_products': similar_products.data})


def category(request, category_slug):
    category = get_object_or_404(Category, slug=category_slug)
    products = Product.objects.filter(visible=True).filter(category__sub_category__category__title = category)

    if request.method == 'POST':
        cart = Cart(request)

        form = AddToCartInListForm(request.POST)
        
        if form.is_valid():
            product_slug = form.cleaned_data['slug']
        
            product = get_object_or_404(
                Product, category__sub_category__category__slug=category_slug, slug=product_slug)
            product.num_visits = product.num_visits + 1
            product.last_visit = datetime.now()
            product.save()
            
            cart.add(product_id=product.id, quantity=1, update_quantity=False)

            messages.success(request, 'The product was added to the cart')

            return redirect('category', category_slug=category_slug)

    return render(request, 'product/category.html', {'category': category, 'products': products})

@api_view()
def category_api(request, category_slug):
    category = get_object_or_404(Category, slug=category_slug)
    products = Product.objects.filter(visible=True).filter(category__sub_category__category__title=category)

    if request.method == 'POST':
        cart = Cart(request)

        form = AddToCartInListForm(request.POST)

        if form.is_valid():
            product_slug = form.cleaned_data['slug']

            product = get_object_or_404(
                Product, category__sub_category__category__slug=category_slug, slug=product_slug)
            product.num_visits = product.num_visits + 1
            product.last_visit = datetime.now()
            product.save()

            cart.add(product_id=product.id, quantity=1, update_quantity=False)

            messages.success(request, 'The product was added to the cart')

            return redirect('category', category_slug=category_slug)
    category = CategorySerializer(category)
    products = ProductSerializer(products , many=True)
    return Response({'category': category.data, 'products': products.data})


def subcategory(request, category_slug, subcategory_slug):
    category = get_object_or_404(SubCategory, slug=subcategory_slug)
    products = Product.objects.filter(visible=True).filter(category__sub_category__title = category)

    if request.method == 'POST':
        cart = Cart(request)

        form = AddToCartInListForm(request.POST)
        
        if form.is_valid():
            product_slug = form.cleaned_data['slug']
        
            product = get_object_or_404(
                Product, category__sub_category__slug=subcategory_slug, slug=product_slug)
            product.num_visits = product.num_visits + 1
            product.last_visit = datetime.now()
            product.save()
            
            cart.add(product_id=product.id, quantity=1, update_quantity=False)

            messages.success(request, 'The product was added to the cart')

            return redirect('subcategory', category_slug=category_slug, subcategory_slug=subcategory_slug)

    return render(request, 'product/subcategory.html', {'category': category, 'products': products})


def subsubcategory(request, category_slug, subcategory_slug, subsubcategory_slug):
    category = get_object_or_404(SubSubCategory, slug=subsubcategory_slug)
    products = Product.objects.filter(visible=True).filter(category__title = category)

    if request.method == 'POST':
        cart = Cart(request)

        form = AddToCartInListForm(request.POST)
        
        if form.is_valid():
            product_slug = form.cleaned_data['slug']
        
            product = get_object_or_404(
                Product, category__slug=subsubcategory_slug, slug=product_slug)
            product.num_visits = product.num_visits + 1
            product.last_visit = datetime.now()
            product.save()
            
            cart.add(product_id=product.id, quantity=1, update_quantity=False)

            messages.success(request, 'The product was added to the cart')

            return redirect('subsubcategory', category_slug=category_slug, subcategory_slug=subcategory_slug, subsubcategory_slug=subsubcategory_slug)

    return render(request, 'product/subsubcategory.html', {'category': category, 'products': products})

@api_view()
def subcategory_api(request, category_slug, subcategory_slug):
    category = get_object_or_404(SubCategory, slug=subcategory_slug)
    products = Product.objects.filter(visible=True).filter(category__sub_category__title=category)

    if request.method == 'POST':
        cart = Cart(request)

        form = AddToCartInListForm(request.POST)

        if form.is_valid():
            product_slug = form.cleaned_data['slug']

            product = get_object_or_404(
                Product, category__sub_category__slug=subcategory_slug, slug=product_slug)
            product.num_visits = product.num_visits + 1
            product.last_visit = datetime.now()
            product.save()

            cart.add(product_id=product.id, quantity=1, update_quantity=False)

            messages.success(request, 'The product was added to the cart')

            return redirect('subcategory', category_slug=category_slug, subcategory_slug=subcategory_slug)
    category = CategorySerializer(category)
    products = ProductSerializer(products, many=True)
    return Response({'category': category.data, 'products': products.data})

@api_view()
def subsubcategory_api(request, category_slug, subcategory_slug, subsubcategory_slug):
    category = get_object_or_404(SubSubCategory, slug=subsubcategory_slug)
    products = Product.objects.filter(visible=True).filter(category__title=category)

    if request.method == 'POST':
        cart = Cart(request)

        form = AddToCartInListForm(request.POST)

        if form.is_valid():
            product_slug = form.cleaned_data['slug']

            product = get_object_or_404(
                Product, category__slug=subsubcategory_slug, slug=product_slug)
            product.num_visits = product.num_visits + 1
            product.last_visit = datetime.now()
            product.save()

            cart.add(product_id=product.id, quantity=1, update_quantity=False)

            messages.success(request, 'The product was added to the cart')

            return redirect('subsubcategory', category_slug=category_slug, subcategory_slug=subcategory_slug,
                            subsubcategory_slug=subsubcategory_slug)
    category = CategorySerializer(category)
    products = ProductSerializer(products, many=True)
    return Response({'category': category.data, 'products': products.data})

