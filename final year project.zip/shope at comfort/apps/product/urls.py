from django.urls import path

from . import views

urlpatterns = [
    path('search_api/', views.search_api, name='search_api'),
    path('api/<vendorslug>/<slug:category_slug>/<slug:subcategory_slug>/<slug:subsubcategory_slug>/<slug:product_slug>/', views.product_api, name='product_api'),
    path('api/<slug:category_slug>/', views.category_api, name='category_api'),
    path('api/<slug:category_slug>/<slug:subcategory_slug>/', views.subcategory_api, name='subcategory_api'),
    path('api/<slug:category_slug>/<slug:subcategory_slug>/<slug:subsubcategory_slug>/', views.subsubcategory_api, name='subsubcategory_api'),



    path('quickview/', views.quickview, name='quickview'),
    path('search/', views.search, name='search'),
    path('<vendorslug>/<slug:category_slug>/<slug:subcategory_slug>/<slug:subsubcategory_slug>/<slug:product_slug>/',views.product, name='product'),
    path('<slug:category_slug>/', views.category, name='category'),
    path('<slug:category_slug>/<slug:subcategory_slug>/', views.subcategory, name='subcategory'),
    path('<slug:category_slug>/<slug:subcategory_slug>/<slug:subsubcategory_slug>/', views.subsubcategory,name='subsubcategory'),

]
