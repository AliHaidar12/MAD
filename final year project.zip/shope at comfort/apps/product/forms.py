from django import forms
from django.forms import ModelForm
from .models import Product_Review

class AddToCartForm(forms.Form):
    quantity = forms.IntegerField()

class ReviewForm(ModelForm):
    class Meta:
        model = Product_Review
        fields = ['rating']

class AddToCartInListForm(forms.Form):
    slug = forms.CharField(max_length=50)
