from django.urls import path

from . import views

urlpatterns = [
    path('', views.cart_detail, name='cart'),
    path('contact_info', views.contact_info, name='contact_info'),
    path('payment_check', views.payment_check, name='payment_check'),
    path('success', views.success, name='success'),
    path('remove_from_cart', views.remove_from_cart, name='remove_from_cart'),
    path('add_to_cart', views.add_to_cart, name='add_to_cart'),

    path('district_sector', views.district_sector, name='district_sector'),
    path('district_sector_cell', views.district_sector_cell, name='district_sector_cell'),
    path('district_sector_cell_village', views.district_sector_cell_village, name='district_sector_cell_village')    
]
