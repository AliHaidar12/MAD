import copy
x = [1,2,3,4,5]
y = copy.deepcopy(x)

y.remove(1)

print("X : {} , Y : {}".format(x,y))

# what is x
# options : ( [1,2,3,4,5] ), ( [1,3,4,5] ) , ( [2,3,4,5] )
# correct : ( [2,3,4,5] )